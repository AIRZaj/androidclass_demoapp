﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=8.5
@EndOfDesignText@
Sub Class_Globals
	Private Root As B4XView 'ignore
	Private xui As XUI 'ignore
	
	Private NavBar1 As NavBar
End Sub

'You can add more parameters here.
Public Sub Initialize As Object
	Return Me
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	'load the layout to Root

	Root.LoadLayout("Page3")
	NavBar1.Initialize(Root)
	
	'to show how to access an object in another Page.
	Public Page21 As B4XPage2 = B4XPages.GetPage("Page 2")
	If Page21.lblTest.IsInitialized Then
		Page21.lblTest.Text = "Page 3 was displayed."
	End If
End Sub

'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.