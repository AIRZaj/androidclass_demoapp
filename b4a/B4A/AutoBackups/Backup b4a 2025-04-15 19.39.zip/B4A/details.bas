﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13.1
@EndOfDesignText@
Sub Class_Globals
	Private Root As B4XView
	Private xui As XUI
	'Private lblInfo As B4XView
	Dim lbl As Label
	Dim info As String
	Private Panel1 As B4XView
	Private lblName As B4XView
	Private lblTitle As B4XView
	Private lblDept As B4XView
	Private lblRoom As B4XView
	Private lblPhone As B4XView
	Private lblMail As B4XView
	Private ImgAvatar As B4XView
End Sub

Public Sub Initialize
	' Do nothing
End Sub



Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	Root.Color = xui.Color_White
	Root.LoadLayout("detail2")
	
	
	' Tworzenie etykiety w sposób zgodny z B4XPages
	'Dim lbl As Label
	'lbl.Initialize("")
	'lbl.TextSize = 16
	'lbl.TextColor = xui.Color_White
	'lbl.Text = "Szczegóły osoby..."
	'lbl.Color = xui.Color_Black
    
	' Konwersja Label na B4XView
	'lblInfo = lbl
	'lblInfo.SetTextAlignment("TOP", "LEFT") ' Ustawienie wyrównania tekstu
    
	' Dodanie etykiety do Root
	'Root.AddView(lblInfo, 10dip, 10dip, 90%x, 100dip) ' Wysokość dostosowana do treści
	
End Sub

Sub CreateRoundBitmap (Input As B4XBitmap, Size As Int) As B4XBitmap
	If Input.Width <> Input.Height Then
		'if the image is not square then we crop it to be a square.
		Dim l As Int = Min(Input.Width, Input.Height)
		Input = Input.Crop(Input.Width / 2 - l / 2, Input.Height / 2 - l / 2, l, l)
	End If
	Dim c As B4XCanvas
	Dim xview As B4XView = xui.CreatePanel("")
	xview.SetLayoutAnimated(0, 0, 0, Size, Size)
	c.Initialize(xview)
	Dim path As B4XPath
	path.InitializeOval(c.TargetRect)
	c.ClipPath(path)
	c.DrawBitmap(Input.Resize(Size, Size, False), c.TargetRect)
	c.RemoveClip
	c.DrawCircle(c.TargetRect.CenterX, c.TargetRect.CenterY, c.TargetRect.Width / 2 - 2dip, xui.Color_White, False, 5dip) 'comment this line to remove the border
	c.Invalidate
	Dim res As B4XBitmap = c.CreateBitmap
	c.Release
	Return res
End Sub

'ImageView1 type is B4XView
Dim img As B4XBitmap = xui.LoadBitmap(File.DirAssets, "ImgAvatar.png")
ImgAvatar.SetBitmap(CreateRoundBitmap(img, ImgAvatar.Width))

Public Sub LoadPerson(p As Map)
	'lblTitle.Text = $"Tytuł: ${p.Get("tytul")}"$
	lblName.Text = $"${p.Get("imie")} ${p.Get("nazwisko")}"$
	lblDept.Text = $"${p.Get("zaklad")}"$
	lblRoom.Text = $"${p.Get("pokoj")}"$
	lblMail.Text = $"${p.Get("mail")}"$
	'lblPhone.Text = $"Telefon: ${p.Get("numer_telefonu")}"$
End Sub

'Public Sub LoadPerson(p As Map) - test na chwile wylaczone
	'Dim info As String
	'info = $"Imię: ${p.Get("imie")}
'Nazwisko: ${p.Get("nazwisko")}
'Tytuł: ${p.Get("tytul")}
'Zakład: ${p.Get("zaklad")}
'Pokój: ${p.Get("pokoj")}
'Telefon: ${p.Get("numer_telefonu")}"$
    
'	lblInfo.Text = info
'End Sub