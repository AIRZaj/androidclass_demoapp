﻿B4J=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=8.5
@EndOfDesignText@
Sub Class_Globals
'	Private fx As JFX
	Private xui As XUI
	
	Private pnlParent As B4XView
	Public btnMainPage As Panel
	Private MP As B4XMainPage
	Public btnPage2 As Panel
	Public btnPage3 As Panel
	Public btnPage4 As Panel
End Sub

'Initializes the object. You can add parameters to this method if needed.
Public Sub Initialize(Parent As B4XView)
	pnlParent = Parent
	
	MP = B4XPages.MainPage
	pnlParent.LoadLayout("NavBar")
End Sub

Private Sub btnNavBar_Click
	Private btn As Panel
	Private Index As Int
	
	btn = Sender
	Index = btn.Tag

	Dim LabelBorderDefault As ColorDrawable
	Dim LabelBorder As ColorDrawable
	LabelBorderDefault.initialize2(Colors.Transparent,0dip,0dip,Colors.Transparent)
	btnMainPage.Background=LabelBorderDefault
	btnPage2.Background=LabelBorderDefault
	btnPage3.Background=LabelBorderDefault
	btnPage4.Background=LabelBorderDefault
	

	Select Index
		Case 0
			MP.CurrentPage = MP
			B4XPages.ShowPageAndRemovePreviousPages("MainPage")
		Case 1
			MP.CurrentPage = MP.Page2
			B4XPages.ShowPageAndRemovePreviousPages("Page 2")
		Case 2
'			MP.CurrentPage = MP.Page3
'			B4XPages.ShowPageAndRemovePreviousPages("Page 3")
		Case 3
			MP.CurrentPage = MP.Page4
			B4XPages.ShowPageAndRemovePreviousPages("Page 4")
	End Select
End Sub
